
#ifndef __TS3_SYSTEM_PLATFORM_OSAPI_X11_OPENGL_H__
#define __TS3_SYSTEM_PLATFORM_OSAPI_X11_OPENGL_H__

#include "x11_window.h"
#include <GL/glx.h>
#include <GL/glxext.h>

namespace ts3
{

    struct SysGLSurfaceNativeData : public SysWindowNativeData
    {
        GLXFBConfig glxFBConfig = nullptr;
        XVisualInfo * xvisualInfo = nullptr;
    };

    struct SysGLContextNativeData
    {
        Display * display;
        GLXDrawable targetSurface;
        GLXContext contextHandle;
    };

}

#endif // __TS3_SYSTEM_PLATFORM_OSAPI_X11_OPENGL_H__
