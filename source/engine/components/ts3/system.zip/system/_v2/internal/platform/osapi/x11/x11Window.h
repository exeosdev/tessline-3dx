
#ifndef __TS3_SYSTEM_PLATFORM_OSAPI_X11_WINDOW_H__
#define __TS3_SYSTEM_PLATFORM_OSAPI_X11_WINDOW_H__

#include "x11_common.h"

namespace ts3
{

    struct SysX11WindowNativeData
    {
        Display * display = nullptr;
        Window xWindow = XID_None;
        Colormap xColormap = XID_None;
    };

    struct SysX11WindowCreateInfo
    {
        SysWindowProperties commonProperties;
        Display * display = nullptr;
        int screenIndex = -1;
        Window rootWindow = cvXIDNone;
        int colorDepth = 0;
        Visual * windowVisual = nullptr;
        Atom wmpDeleteWindow = -1;
        bool fullscreenMode = false;
    };

    using SysWindowNativeData = SysX11WindowNativeData;
    using SysWindowCreateInfo = SysX11WindowCreateInfo;

    void sysX11CreateWindow( SysWindowNativeData & pWindowData, const SysX11WindowCreateInfo & pCreateInfo );
    void sysX11UpdateNewWindowState( SysWindowNativeData & pWindowData, const SysX11WindowCreateInfo & pCreateInfo );
    void sysX11DestroyWindow( SysWindowNativeData & pWindowData );

}

#endif // __TS3_SYSTEM_PLATFORM_OSAPI_X11_WINDOW_H__
