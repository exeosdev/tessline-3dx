
#ifndef __TS3_SYSTEM_PLATFORM_OSAPI_X11_EVENT_CORE_H__
#define __TS3_SYSTEM_PLATFORM_OSAPI_X11_EVENT_CORE_H__

#include "x11_common.h"

namespace ts3
{

    enum class SysX11MouseButtonID : enum_default_value_t
    {
        Unknown,
        Left,
        Middle,
        Right,
        VWheelUp,
        VWheelDown,
        HWheelLeft,
        HWheelRight,
        XButton1,
        XButton2
    };

}

#endif // __TS3_SYSTEM_PLATFORM_OSAPI_X11_EVENT_CORE_H__
