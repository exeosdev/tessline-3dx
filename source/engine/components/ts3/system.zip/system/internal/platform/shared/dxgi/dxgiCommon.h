
#ifndef __TS3_SYSTEM_DXGI_COMMON_H__
#define __TS3_SYSTEM_DXGI_COMMON_H__

#include "../winfamily/winfamilyCommon.h"

#include <dxgi.h>
#include <dxgi1_2.h>
#include <dxgi1_3.h>

#endif // __TS3_SYSTEM_DXGI_COMMON_H__
