
#ifndef __TS3_SYSTEM_PLATFORM_SHARED_WINFAMILY_PERF_COUNTER_H__
#define __TS3_SYSTEM_PLATFORM_SHARED_WINFAMILY_PERF_COUNTER_H__

#include <ts3/system/perfCounter.h>

// No additional includes or defines for WinFamily - Windows.h contains all needed stuff.

#endif // __TS3_SYSTEM_PLATFORM_SHARED_WINFAMILY_PERF_COUNTER_H__
