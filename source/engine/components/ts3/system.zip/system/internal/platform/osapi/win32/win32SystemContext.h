
#ifndef __TS3_SYSTEM_PLATFORM_OSAPI_WIN32_SYSTEM_CONTEXT_H__
#define __TS3_SYSTEM_PLATFORM_OSAPI_WIN32_SYSTEM_CONTEXT_H__

#include "win32Common.h"

namespace ts3
{

	struct SysContextNativeData
	{
	};

	struct SysContextNativeCreateInfo
	{
	};

}

#endif // __TS3_SYSTEM_PLATFORM_OSAPI_WIN32_SYSTEM_CONTEXT_H__
