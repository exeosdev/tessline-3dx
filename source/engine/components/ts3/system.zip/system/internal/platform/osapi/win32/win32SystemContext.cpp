
#include <ts3/system/systemContext.h>

namespace ts3
{

	void SysContext::_sysInitialize( const SysContextCreateInfo & pCreateInfo )
	{}

	void SysContext::_sysRelease() noexcept
	{}

}
