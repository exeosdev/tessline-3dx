
#ifndef __TS3_SYSTEM_PLATFORM_OSAPI_ANDROID_WINDOW_H__
#define __TS3_SYSTEM_PLATFORM_OSAPI_ANDROID_WINDOW_H__

#include "androidEventCore.h"

namespace ts3
{

	struct SysWindowNativeData : public SysEventSourceNativeData
	{
	};

}

#endif // __TS3_SYSTEM_PLATFORM_OSAPI_ANDROID_WINDOW_H__
