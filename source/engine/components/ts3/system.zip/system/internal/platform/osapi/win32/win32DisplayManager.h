
#ifndef __TS3_SYSTEM_PLATFORM_OSAPI_WIN32_DISPLAY_MANAGER_H__
#define __TS3_SYSTEM_PLATFORM_OSAPI_WIN32_DISPLAY_MANAGER_H__

#include "win32Common.h"

namespace ts3
{

	struct SysDisplayManagerNativeData
	{
	};

}

#endif // __TS3_SYSTEM_PLATFORM_OSAPI_WIN32_DISPLAY_MANAGER_H__
