
#ifndef __TS3_SYSTEM_PLATFORM_OSAPI_WIN32_SYSTEM_UTILS_H__
#define __TS3_SYSTEM_PLATFORM_OSAPI_WIN32_SYSTEM_UTILS_H__

#include "../../shared/winfamily/winfamilySystemUtils.h"

namespace ts3
{
}

#endif // __TS3_SYSTEM_PLATFORM_OSAPI_WIN32_SYSTEM_UTILS_H__
